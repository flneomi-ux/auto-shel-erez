# האוטו של ארז — Android

אפליקציית Android מקורית (Kotlin + Jetpack Compose), עם מסך בעברית ובכיווניות RTL.

## מה כלול
- ניווט לכתובות השמורות באמצעות Waze, עם מעבר ל-Google Maps אם Waze אינו מותקן.
- בחירת קובצי מוזיקה מקומיים ושמירת הרשאות גישה לקבצים.
- נגן Media3 ושירות MediaLibraryService המיועד לחשיפה ל-Android Auto.
- כפתור חיוג לשער: `0733656230`.
- כפתור חיוג לאהבה שלי: `0525679888`.

## בניית APK אוטומטית
המאגר כולל GitHub Actions בקובץ `.github/workflows/build.yml`.
ה-workflow מופעל בכל push או ידנית דרך Actions → Build Android APK → Run workflow.
לאחר הצלחה, קובץ ההתקנה נמצא ב-Artifacts בשם `auto-shel-erez-debug-apk`.

## דרישות ואימות
- JDK 17
- Android SDK Platform 35 ו-Build Tools 35.0.0
- Gradle 8.9

הקובץ `app-debug.apk` הוא APK לבדיקה/התקנה (חתימת debug). יש לאמת התקנה, הרשאות קובצי מוזיקה, ניווט וטלפוניה במכשיר Android אמיתי. תאימות Android Auto מחייבת גם בדיקה ברכב או ב-Desktop Head Unit; קיום השירות לבדו אינו מהווה אישור תאימות.

## פרטי הפרויקט
- Application ID: `il.erez.autoshel`
- Minimum Android: 8.0 (API 26)
- Target Android: API 35
