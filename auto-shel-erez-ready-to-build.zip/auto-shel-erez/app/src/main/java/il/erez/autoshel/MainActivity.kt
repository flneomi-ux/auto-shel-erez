package il.erez.autoshel

import android.content.ComponentName
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.DoorFront
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.MoreExecutors

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private var controllerState by mutableStateOf(Player.STATE_IDLE)
    private var isPlaying by mutableStateOf(false)
    private var currentTitle by mutableStateOf("לא נבחר שיר")

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val saved = prefs.getString(TRACKS_ORDERED, null)
            ?.split("\n")?.filter { it.isNotBlank() }?.toMutableList()
            ?: prefs.getStringSet(TRACKS, emptySet()).orEmpty().toMutableList().sorted().toMutableList()
        uris.forEach { uri ->
            runCatching {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            if (uri.toString() !in saved) saved.add(uri.toString())
        }
        prefs.edit()
            .putString(TRACKS_ORDERED, saved.joinToString("\n"))
            .putStringSet(TRACKS, saved.toSet()) // compatibility with the first prototype
            .apply()
        loadSavedLibrary(autoPlay = true)
        // Tell Android Auto that the browsable library has changed.
        startService(Intent(this, CarMusicService::class.java).setAction(CarMusicService.ACTION_REFRESH_LIBRARY))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val token = SessionToken(this, ComponentName(this, CarMusicService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            runCatching {
                controller = future.get().also { c ->
                    c.addListener(object : Player.Listener {
                        override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
                        override fun onPlaybackStateChanged(playbackState: Int) { controllerState = playbackState }
                        override fun onMediaMetadataChanged(mediaMetadata: androidx.media3.common.MediaMetadata) {
                            currentTitle = mediaMetadata.title?.toString() ?: "מוזיקה"
                        }
                    })
                    c.addListener(object : Player.Listener {
                        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                            currentTitle = mediaItem?.mediaMetadata?.title?.toString()
                                ?: c.mediaMetadata.title?.toString() ?: "מוזיקה"
                        }
                    })
                    isPlaying = c.isPlaying
                    currentTitle = c.mediaMetadata.title?.toString() ?: "לא נבחר שיר"
                    // Restore the saved library when the service/controller connects.
                    if (c.mediaItemCount == 0) loadSavedLibrary(autoPlay = false)
                }
            }
        }, MoreExecutors.directExecutor())

        setContent {
            Dashboard(
                title = currentTitle,
                playing = isPlaying,
                onNav = ::openWaze,
                onGate = { dial("0733656230") },
                onLove = { dial("0525679888") },
                onPick = { picker.launch(arrayOf("audio/*")) },
                onPlay = { controller?.play() },
                onPause = { controller?.pause() },
                onStop = { controller?.stop() },
                onNext = { controller?.seekToNextMediaItem() },
                onPrevious = { controller?.seekToPreviousMediaItem() }
            )
        }
    }

    private fun loadSavedLibrary(autoPlay: Boolean) {
        val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
        val ordered = prefs.getString(TRACKS_ORDERED, null)
            ?.split("\n")?.filter { it.isNotBlank() }
            ?: prefs.getStringSet(TRACKS, emptySet()).orEmpty().toList().sorted()
        val items = ordered.distinct().map { raw ->
            val uri = Uri.parse(raw)
            val displayName = runCatching {
                contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                }
            }.getOrNull() ?: uri.lastPathSegment ?: "שיר"
            MediaItem.Builder().setMediaId(raw).setUri(uri).setMediaMetadata(
                androidx.media3.common.MediaMetadata.Builder()
                    .setTitle(displayName.substringBeforeLast('.', displayName))
                    .setArtist("האוטו של ארז")
                    .build()
            ).build()
        }
        controller?.let { c ->
            c.setMediaItems(items)
            c.prepare()
            if (autoPlay && items.isNotEmpty()) c.play()
        }
    }

    private fun openWaze(address: String) {
        val wazeUri = Uri.parse("https://waze.com/ul?q=${Uri.encode(address)}&navigate=yes")
        val waze = Intent(Intent.ACTION_VIEW, wazeUri).setPackage("com.waze")
        if (waze.resolveActivity(packageManager) != null) startActivity(waze)
        else {
            val mapsUri = Uri.parse("https://www.google.com/maps/search/?api=1&query=${Uri.encode(address)}")
            startActivity(Intent(Intent.ACTION_VIEW, mapsUri))
        }
    }

    private fun dial(number: String) {
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$number")))
    }

    override fun onDestroy() {
        controller?.release()
        super.onDestroy()
    }

    companion object {
        const val PREFS = "erez_music_library"
        const val TRACKS = "track_uris"
        const val TRACKS_ORDERED = "track_uris_ordered"
    }
}

@Composable
private fun Dashboard(
    title: String, playing: Boolean,
    onNav: (String) -> Unit, onGate: () -> Unit, onLove: () -> Unit,
    onPick: () -> Unit, onPlay: () -> Unit, onPause: () -> Unit,
    onStop: () -> Unit, onNext: () -> Unit, onPrevious: () -> Unit
) {
    val bg = Color(0xFF0B1017)
    val panel = Color(0xFF192431)
    val cyan = Color(0xFF48E0D2)
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(colorScheme = darkColorScheme(primary = cyan, background = bg, surface = panel)) {
            Column(
                Modifier.fillMaxSize().background(bg).verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(13.dp)
            ) {
                Text("האוטו של ארז", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.ExtraBold)
                Text("הדרך שלך. המוזיקה שלך.", color = Color(0xFF9EAFBF), fontSize = 14.sp)
                Spacer(Modifier.height(2.dp))
                Text("לאן נוסעים?", color = cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    NavCard("הביתה", "ששת הימים 1 · חולון", Modifier.weight(1f)) { onNav("ששת הימים 1, חולון, ישראל") }
                    NavCard("לאמא", "דוד אלעזר 65 · חולון", Modifier.weight(1f)) { onNav("דוד אלעזר 65, חולון, ישראל") }
                }
                NavCard("לסודן", "וולפסון 86 · תל אביב-יפו", Modifier.fillMaxWidth()) { onNav("וולפסון 86, תל אביב-יפו, ישראל") }
                Text("המוזיקה שלי", color = cyan, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Vinyl(title, playing, onPick)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onPrevious) { Icon(Icons.Default.SkipPrevious, contentDescription = "שיר קודם", tint = Color.White) }
                    FilledIconButton(onClick = if (playing) onPause else onPlay, modifier = Modifier.size(58.dp)) {
                        Icon(if (playing) Icons.Default.Pause else Icons.Default.PlayArrow, contentDescription = if (playing) "השהה" else "נגן")
                    }
                    IconButton(onClick = onStop) { Icon(Icons.Default.Stop, contentDescription = "עצור", tint = Color.White) }
                    IconButton(onClick = onNext) { Icon(Icons.Default.SkipNext, contentDescription = "שיר הבא", tint = Color.White) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    ActionCard("פתח שער", Icons.Default.DoorFront, Modifier.weight(1f), onGate)
                    ActionCard("חייג לאהבה שלי", Icons.Default.Call, Modifier.weight(1f), onLove)
                }
                Text("החיוג נפתח בחייגן וממתין לאישור שלך.", color = Color(0xFF718294), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun NavCard(title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color(0xFF192431)), shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
            Text(sub, color = Color(0xFF9EAFBF), fontSize = 12.sp)
        }
    }
}

@Composable
private fun ActionCard(title: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.height(72.dp).clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color(0xFF192431)), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.fillMaxSize().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
            Icon(icon, null, tint = Color(0xFF48E0D2))
            Spacer(Modifier.width(7.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
        }
    }
}

@Composable
private fun Vinyl(title: String, playing: Boolean, onPick: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "vinyl")
    val angle by transition.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(2600, easing = LinearEasing), RepeatMode.Restart),
        label = "rotation"
    )
    Row(
        Modifier.fillMaxWidth().background(Color(0xFF192431), RoundedCornerShape(20.dp)).clickable { onPick() }.padding(15.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(88.dp).rotate(if (playing) angle else 0f).background(Color(0xFF05070A), CircleShape), contentAlignment = Alignment.Center) {
            Box(Modifier.size(68.dp).background(Color(0xFF151B22), CircleShape))
            Box(Modifier.size(47.dp).background(Color(0xFF262E38), CircleShape))
            Box(Modifier.size(29.dp).background(Color(0xFF48E0D2), CircleShape))
            Box(Modifier.size(6.dp).background(Color.Black, CircleShape))
        }
        Spacer(Modifier.width(15.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 2)
            Spacer(Modifier.height(5.dp))
            Text("לחץ לבחירת שירים מהטלפון", color = Color(0xFF9EAFBF), fontSize = 12.sp)
        }
    }
}
