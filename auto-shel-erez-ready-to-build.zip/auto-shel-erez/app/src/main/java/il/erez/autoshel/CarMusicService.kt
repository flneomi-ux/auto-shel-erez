package il.erez.autoshel

import android.net.Uri
import android.provider.OpenableColumns
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaLibrarySession
import androidx.media3.session.MediaSession
import com.google.common.collect.ImmutableList
import androidx.media3.session.MediaLibraryService.LibraryParams
import androidx.media3.session.MediaLibraryService.LibraryResult
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture

@UnstableApi
class CarMusicService : MediaLibraryService() {
    private lateinit var player: ExoPlayer
    private lateinit var librarySession: MediaLibrarySession

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this).build().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build(), true)
            setHandleAudioBecomingNoisy(true)
        }
        // Load the persisted library when the service starts, even if the phone
        // Activity has never been opened. Android Auto can then browse and play
        // the user's tracks directly from the car display.
        val initialTracks = savedTracks()
        if (initialTracks.isNotEmpty()) {
            player.setMediaItems(initialTracks)
            player.prepare()
        }
        librarySession = MediaLibrarySession.Builder(this, player, LibraryCallback()).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession = librarySession

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_REFRESH_LIBRARY && ::librarySession.isInitialized) {
            val updatedTracks = savedTracks()
            // Keep the active playback intact when the library is merely refreshed.
            if (player.mediaItemCount == 0 && updatedTracks.isNotEmpty()) {
                player.setMediaItems(updatedTracks)
                player.prepare()
            }
            librarySession.notifyChildrenChanged(ROOT_ID, updatedTracks.size, null)
        }
        return super.onStartCommand(intent, flags, startId)
    }

    override fun onDestroy() {
        librarySession.release()
        player.release()
        super.onDestroy()
    }

    private fun savedTracks(): List<MediaItem> {
        val prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
        val ordered = prefs.getString(MainActivity.TRACKS_ORDERED, null)
            ?.split("\n")?.filter { it.isNotBlank() }
            ?: prefs.getStringSet(MainActivity.TRACKS, emptySet()).orEmpty().toList().sorted()
        return ordered.distinct().mapNotNull { raw ->
            runCatching {
                val uri = Uri.parse(raw)
                val title = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) c.getString(0) else null
                } ?: uri.lastPathSegment ?: "שיר"
                MediaItem.Builder().setMediaId(raw).setUri(uri).setMediaMetadata(
                    MediaMetadata.Builder().setTitle(title.substringBeforeLast('.', title)).setArtist("האוטו של ארז").setIsBrowsable(false).setIsPlayable(true).build()
                ).build()
            }.getOrNull()
        }
    }

    private inner class LibraryCallback : MediaLibrarySession.Callback {
        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<MediaItem>> {
            val root = MediaItem.Builder().setMediaId(ROOT_ID).setMediaMetadata(
                MediaMetadata.Builder().setTitle("האוטו של ארז").setSubtitle("ספריית המוזיקה").setIsBrowsable(true).setIsPlayable(false).build()
            ).build()
            return Futures.immediateFuture(LibraryResult.ofItem(root, params))
        }

        override fun onGetChildren(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            parentId: String,
            page: Int,
            pageSize: Int,
            params: LibraryParams?
        ): ListenableFuture<LibraryResult<ImmutableList<MediaItem>>> {
            val tracks = if (parentId == ROOT_ID) savedTracks() else emptyList()
            val from = (page * pageSize).coerceAtMost(tracks.size)
            val to = (from + pageSize).coerceAtMost(tracks.size)
            // Media3 requires ImmutableList as the library result type.
            return Futures.immediateFuture(
                LibraryResult.ofItemList(ImmutableList.copyOf(tracks.subList(from, to)), params)
            )
        }

        override fun onGetItem(session: MediaLibrarySession, browser: MediaSession.ControllerInfo, mediaId: String): ListenableFuture<LibraryResult<MediaItem>> {
            val item = savedTracks().firstOrNull { it.mediaId == mediaId }
                ?: return Futures.immediateFuture(LibraryResult.ofError(LibraryResult.RESULT_ERROR_BAD_VALUE))
            return Futures.immediateFuture(LibraryResult.ofItem(item, null))
        }
    }

    companion object {
        private const val ROOT_ID = "erez_music_root"
        const val ACTION_REFRESH_LIBRARY = "il.erez.autoshel.action.REFRESH_LIBRARY"
    }
}
